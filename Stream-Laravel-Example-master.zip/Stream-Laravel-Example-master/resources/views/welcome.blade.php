@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Welcome</div>

                <div class="panel-body">
                    This is the Landing Page for Tasker -
                    the official, and also somehow unofficial, Stream Laravel 5.2 Example Application.
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
